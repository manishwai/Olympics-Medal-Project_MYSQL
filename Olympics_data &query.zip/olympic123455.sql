use sports;
show tables;
drop table athelete_table;
select count(*) from athelete_table2;
select count(*) from nocregion;

###1How many olympics games have been held?
select   count(distinct games) from athelete_table2;

###2List down all Olympics games held so far.
select distinct games from athelete_table2;

###3Mention the total no of nations who participated in each olympics game?
select games , count( distinct team ) as count  from athelete_table2
group by games 
order by count desc;


###4Which year saw the highest and lowest no of countries participating in olympics?


select games ,year ,  count( distinct team ) as count  from athelete_table2
group by games ,year
order by count desc
limit 1;



###5Which nation has participated in all of the olympic games?
 use sports;
 select  distinct team , count( distinct games) as count   from athelete_table2
 group by team
 having count = (select count(distinct games ) from athelete_table2)
 order by count desc; 

###6Identify the sport which was played in all summer olympics.
 select sport ,count(distinct games)as count 
 from athelete_table2
 where season="Summer"
 group by sport
 having count = ( select count(distinct games) from athelete_table2 where season ="summer");

###7Which Sports were just played only once in the olympics?

select sport,games ,count( games) as count  from athelete_table2
group by sport,games 
having count=1;
  



###8Fetch the total no of sports played in each olympic games.
 select  distinct games, count( distinct sport) as count 
 from athelete_table2
 group by games
 order by count desc;
 
###9Fetch details of the oldest athletes to win a gold medal.
with t1 as (select * ,
case when age ="NA" then 0 else age end as age2
from athelete_table2)
select * from t1 
where  medal ="gold" and 
age2 in (select max(age2) from t1 where medal="gold");

###10Find the Ratio of male and female athletes participated in all olympic games.
with male_count as
 (select sex , count(name) as count
from athelete_table2
where sex="M"
group by sex
),
female_count as 
(select sex , count(name) as count
from athelete_table2
where sex="F"
group by sex)


###11Fetch the top 5 athletes who have won the most gold medals.

select * from (
select * , rank() over( order by count desc)  as rnk from 
(select name , count(medal) as count
from athelete_table2
where medal="gold"
group by name 
order by count desc) t) b
where rnk<=5;

###12Fetch the top 5 athletes who have won the most medals (gold/silver/bronze).
with total_medals as 
(select name , count(medal) as count from athelete_table2
where medal in ("gold","silver","bronze")
group by name
order by count desc) , 
rankprovided as (
select *, rank() over ( order by count desc)  as rnk
from total_medals)
Select * from rankprovided 
where rnk<=5;

###13Fetch the top 5 most successful countries in olympics. Success is defined by no of medals won.
with t1 as (select team , count(medal) as count 
from athelete_table2
where medal in ( "gold" , "silver","bronze")
group by team ),
t2 as (
select *  , rank() over( order by count desc) rnk
from t1)
select * from t2 where rnk<=5;

###14List down total gold, silver and broze medals won by each country.
with t1 as 
(select team ,games,
case when medal ="gold" then 1 else 0 end as gold_count,
case when medal ="silver" then 1 else 0 end as silver_count,
case when medal ="bronze" then 1 else 0 end as bronze_count, 
case when medal<>"NA"then 1 else 0  end as total_medal_count
from athelete_table2) 
select team , sum(gold_count),sum(silver_count),sum(bronze_count),sum(total_medal_count)
from t1 
group by team;

###15List down total gold, silver and broze medals won by each country corresponding to each olympic games.
with t1 as 
(select team ,games,
case when medal ="gold" then 1 else 0 end as gold_count,
case when medal ="silver" then 1 else 0 end as silver_count,
case when medal ="bronze" then 1 else 0 end as bronze_count
from athelete_table2) 
select team ,games, sum(gold_count),sum(silver_count),sum(bronze_count)
from t1 
group by team,games;

###16Identify which country won the most gold, most silver and most bronze medals in each olympic games.
with t1 as 
(select team ,games,
case when medal ="gold" then 1 else 0 end as gold_count,
case when medal ="silver" then 1 else 0 end as silver_count,
case when medal ="bronze" then 1 else 0 end as bronze_count
from athelete_table2), 
t2 as 
(select games,team  ,sum(gold_count) as total_gold, sum(silver_count)as total_silver, sum(bronze_count) as total_bronze
from t1 
group by team , games
order by games) 

select  distinct games ,
concat (max(total_gold) over (partition by games) , 
first_value(team) over (partition  by  games order by total_gold desc) ) as max_gold,
concat (max(total_silver) over (partition by games) , 
first_value(team) over (partition  by  games order by total_silver desc) ) as max_silver,
concat (max(total_bronze) over (partition by games) , 
first_value(team) over (partition  by  games order by total_bronze desc) ) as max_bronze
 from t2;

###17Identify which country won the most gold, most silver, most bronze medals and the most medals in each olympic games.
with t1 as 
(select team ,games,
case when medal ="gold" then 1 else 0 end as gold_count,
case when medal ="silver" then 1 else 0 end as silver_count,
case when medal ="bronze" then 1 else 0 end as bronze_count, 
case when medal<>"NA"then 1 else 0  end as total_medal_count
from athelete_table2) ,
 t2 as (select team ,games, sum(gold_count) as total_gold,sum(silver_count) as total_silver,sum(bronze_count) as total_bronze,sum(total_medal_count) as total_medals_counts
from t1 
group by team,games
order by games)
select  distinct games ,
concat (max(total_gold) over (partition by games) , 
first_value(team) over (partition  by  games order by total_gold desc) ) as max_gold,
concat (max(total_silver) over (partition by games) , 
first_value(team) over (partition  by  games order by total_silver desc) ) as max_silver,
concat (max(total_bronze) over (partition by games) , 
first_value(team) over (partition  by  games order by total_bronze desc) ) as max_bronze , 
concat(max(total_medals_counts) over (partition by games ) , first_value(team) over (partition by games order by total_medals_counts desc )) as max_medals
 from t2;



###18Which countries have never won gold medal but have won silver/bronze medals?
with t1 as 
(select team ,games,
case when medal ="gold" then 1 else 0 end as gold_count,
case when medal ="silver" then 1 else 0 end as silver_count,
case when medal ="bronze" then 1 else 0 end as bronze_count
from athelete_table2) 
select team ,games, sum(gold_count) as total_gold,sum(silver_count),sum(bronze_count)
from t1 
group by team,games
having total_gold=0 ;


###19In which Sport/event, India has won highest medals.
select sport, count(medal) as count from athelete_table2
where team="India" and medal <>"NA"
group by sport
order by count desc 
limit 1;

###20Break down all olympic games where india won medal for Hockey and how many medals in each olympic games.
select  games , count(medal) as count from athelete_table2
where team="India" and medal <>"NA" and sport="hockey"
group by games
order by count desc ;